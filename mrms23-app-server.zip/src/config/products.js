const ticket = {
    id: "(TESTING) TICKET HIMALAYA",
    price: 101,
    name: "(TESTING) Tiket HIMALAYA MR. & MS. UMN 2023",
}


module.exports = {ticket};